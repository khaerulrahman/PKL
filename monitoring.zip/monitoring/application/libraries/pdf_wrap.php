<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pdf_wrap
{
	protected $ci;

	public function __construct()
	{
        $this->ci =& get_instance();
        include_once APPPATH . 'third_party/fpdf/fpdf_wrap.php';
	}

	

}

/* End of file pdf_wrap.php */
/* Location: ./application/libraries/pdf_wrap.php */
