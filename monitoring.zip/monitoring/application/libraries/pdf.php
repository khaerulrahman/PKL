<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pdf
{
	protected $ci;

	public function __construct()
	{
        $this->ci =& get_instance();
        include_once APPPATH . 'third_party/fpdf/fpdf.php';
	}

	

}

/* End of file pdf.php */
/* Location: ./application/libraries/pdf.php */
