<script>
    $(document).ready( function () {
        $('#tabel').DataTable();
    } );
</script>
<div class="row">
    <div class="col-md-12">
     <h3><?php echo $judul ?></h3>    
 </div>
</div>
<!-- /. ROW  -->
<hr />
<a href="<?php echo $add ?>" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Upload Data</a>
<div class="panel-body" style="margin-top: 10px">
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover" id="tabel">
            <thead>
                <tr>
                    <th style="text-align:center">No</th>
                    <th>Material</th>
                    <th>Material Description</th>
                    <th>Val. Type</th>
                    <th>Movement Type Text</th>
                    <th>Order</th>
                    <th>MvT</th>
                    <th>Text</th>
                    <th>Quantity</th>
                    <th>Posting Date</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($query->result() as $key): ?>
                    <tr>
                        <td style="text-align:center"><?php echo ++$no ?></td>
                        <td><?php echo $key->material ?></td>
                        <td><?php echo $key->material_desc ?></td>
                        <td><?php echo $key->val_type ?></td>
                        <td><?php echo $key->movement ?></td>
                        <td><?php echo $key->orderr ?></td>
                        <td><?php echo $key->mvt ?></td>
                        <td><?php echo $key->text ?></td>
                        <td><?php echo $key->quantity ?></td>
                        <td><?php echo date_format(date_create($key->posting_date),'m/d/Y') ?></td>
                        <td>
                            <a href="<?php echo $edit.$key->id ?>" class="btn btn-primary btn-xs"><i class="fa fa-edit "></i> Edit</a>
                            <a href="<?php echo $delete.$key->id ?>" class="btn btn-danger btn-xs" onClick="return confirm('Hapus data <?php echo $key->material ?>?')"><i class="fa fa-eraser "></i> Hapus</a>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>	  	
</div>
                    <!--End Advanced Tables -->