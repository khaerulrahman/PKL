<script>
    $(document).ready( function () {
        $('#tabel').DataTable();
    } );
</script>
<div class="row">
    <div class="col-md-12">
     <h3><?php echo $judul ?></h3>    
 </div>
</div>
<!-- /. ROW  -->
<hr />
<div class="panel-body" style="margin-top: 10px">
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover" id="tabel">
            <thead>
                <tr>
                    <th style="text-align:center">No</th>
                    <th>Material</th>
                    <th>Material Description</th>
                    <th>Batch</th>
                    <th>Bun</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($query->result() as $key): ?>
                    <tr>
                        <td style="text-align:center"><?php echo ++$no ?></td>
                        <td><?php echo $key->material ?></td>
                        <td><?php echo $key->material_desc ?></td>
                        <td><?php echo $key->batch ?></td>
                        <td><?php echo $key->bun ?></td>
                        <td><?php echo $key->quantity ?></td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>	  	
</div>
                    <!--End Advanced Tables -->