<div class="widget ">

    <div class="widget-header">
        <i class="icon-user"></i>
        <h3><?php echo $judul ?></h3>
    </div> <!-- /widget-header -->

    <div class="widget-content">
        <div class="panel panel-default">
            <div class="panel-body">
             <center>
                <form method="POST" action="<?php echo $action ?>">
                    <table>
                        <tr>
                            <td align="right" style="padding: 2px"><h3>Kode Material :</h3></td>
                            <td class="col-md-8" style="padding: 2px"><input class="form-control" name="material" value="<?php echo $material ?>" <?php echo $read ?>></td>
                        </tr>
                        <tr>
                            <td align="right" style="padding: 2px"><h3>Material Description:</h3></td>
                            <td class="col-md-8" style="padding: 2px"><input class="form-control" name="material_desc" value="<?php echo $material_desc ?>" required></td>
                        </tr>
                        <tr>
                          <td align="right" style="padding: 2px"><h3>Minimum Stock :</h3></td>
                          <td class="col-md-8" style="padding: 2px">
                            <input type="text" class="form-control" name="minimum_stock" value="<?php echo $minimum_stock ?>" required>
                        </td>
                    </tr>
                    <td style="padding: 2px">
                        <td>
                            <input class="btn btn-primary" type="submit" value="Simpan">
                            <a href="#" class="btn btn-danger" onclick="self.history.back()">Batal</a>
                        </td>
                    </td>
                </tr>
            </table>
        </form>
    </center>
</div>
</div>
</div>
</div>

