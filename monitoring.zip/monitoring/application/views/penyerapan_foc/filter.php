<div class="widget ">

    <div class="widget-header">
        <i class="icon-user"></i>
        <h3><?php echo $judul ?></h3>
    </div> <!-- /widget-header -->

    <div class="widget-content">
        <div class="panel panel-default">
            <div class="panel-body">
               <center>
                <form method="POST" action="<?php echo $action ?>">
                    <table>
                        <tr>
                            <td align="right" style="padding: 2px"><h3>From Date:</h3></td>
                            <td class="col-md-8" style="padding: 2px"><input type="date" class="form-control" name="from"></td>
                        </tr>
                        <tr>
                            <td align="right" style="padding: 2px"><h3>To Date:</h3></td>
                            <td class="col-md-8" style="padding: 2px"><input type="date" class="form-control" name="to"></td>
                        </tr>
                        <tr>
                          <td align="right" style="padding: 2px"><h3>Movement Type :</h3></td>
                          <td class="col-md-8" style="padding: 2px">
                            <select name="mvt" id="" class="form-control">
                                <option value=""></option>
                                <option value="201">201 (GI For Cost Center)</option>
                                <option value="261">261 (GI For Profect)</option>
                                <option value="961">961 (GI For Activation)</option>
                            </select>
                            </td>
                        </tr>
                        <td style="padding: 2px">
                            <td>
                                <input class="btn btn-primary" type="submit" value="Submit">
                                <a href="#" class="btn btn-danger" onclick="self.history.back()">Batal</a>
                            </td>
                        </td>
                    </tr>
                </table>
        </form>
    </center>
</div>
</div>
</div>
</div>

