<div class="widget ">

    <div class="widget-header">
        <i class="icon-user"></i>
        <h3><?php echo $judul ?></h3>
    </div> <!-- /widget-header -->

    <div class="widget-content">
        <div class="panel panel-default">
            <div class="panel-body">
             <center>
                <form method="POST" action="<?php echo $action ?>"> 
                    <input type="hidden" name="id" value="<?php echo $id ?>">
                    <table>
                        <tr>
                            <td align="right" style="padding: 2px"><h3>Material :</h3></td>
                            <td class="col-md-8" style="padding: 2px"><input class="form-control" name="material" value="<?php echo $material ?>" required></td>
                        </tr>
                        <tr>
                            <td align="right" style="padding: 2px"><h3>Material Description:</h3></td>
                            <td class="col-md-8" style="padding: 2px"><input class="form-control" name="material_desc" value="<?php echo $material_desc ?>" required></td>
                        </tr>
                        <tr>
                            <td align="right" style="padding: 2px"><h3>Jenis Kabel:</h3></td>
                            <td class="col-md-8" style="padding: 2px"><input class="form-control" name="jenis_kabel" value="<?php echo $jenis_kabel ?>" required></td>
                        </tr>
                        <tr>
                            <td align="right" style="padding: 2px"><h3>Val. Type :</h3></td>
                            <td class="col-md-8" style="padding: 2px">
                                <input type="text" class="form-control" name="val_type" value="<?php echo $val_type ?>" required>
                            </td>
                        </tr>
                        <tr>
                            <td align="right" style="padding: 2px"><h3>Movement Type Text :</h3></td>
                            <td class="col-md-8" style="padding: 2px">
                                <input type="text" class="form-control" name="movement" value="<?php echo $movement ?>" required>
                            </td>
                        </tr>
                        <tr>
                          <td align="right" style="padding: 2px"><h3>Batch :</h3></td>
                          <td class="col-md-8" style="padding: 2px">
                            <input type="text" class="form-control" name="batch" value="<?php echo $batch ?>" required>
                        </td>
                        <tr>
                          <td align="right" style="padding: 2px"><h3>MvT :</h3></td>
                          <td class="col-md-8" style="padding: 2px">
                            <input type="text" class="form-control" name="mvt" value="<?php echo $mvt ?>" required>
                        </td>
                        <tr>
                          <td align="right" style="padding: 2px"><h3>Quantity :</h3></td>
                          <td class="col-md-8" style="padding: 2px">
                            <input type="text" class="form-control" name="quantity" value="<?php echo $quantity ?>" required>
                        </td>
                        <tr>
                          <td align="right" style="padding: 2px"><h3>Posting Date :</h3></td>
                          <td class="col-md-8" style="padding: 2px">
                            <input type="date" class="form-control" name="posting_date" value="<?php echo $posting_date ?>" required>
                        </td>
                    </tr>
                    <td style="padding: 2px">
                        <td>
                            <input class="btn btn-primary" type="submit" value="Simpan">
                            <a href="#" class="btn btn-danger" onclick="self.history.back()">Batal</a>
                        </td>
                    </td>
                </tr>
            </table>
        </form>
    </center>
</div>
</div>
</div>
</div>

