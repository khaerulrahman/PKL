<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?php echo isset($judul) ? $judul : 'PT INDONESIA COMNETS PLUS' ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <link href="<?php echo base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/css/bootstrap-responsive.min.css" rel="stylesheet">
  <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
  rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/css/font-awesome.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/css/style.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/css/pages/dashboard.css" rel="stylesheet">
  <!-- <script src="<?php echo base_url() ?>assets/js/jquery-3.3.1.min.js"></script> -->
  <script src="<?php echo base_url() ?>assets/js/jquery-1.7.2.min.js"></script>
  <script src="<?php echo base_url() ?>assets/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <link href="<?php echo base_url() ?>assets/css/jquery.dataTables.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css">
</head>
<body>

  <div class="subnavbar">
    <div class="subnavbar-inner">
      <div class="container">
        <ul class="mainnav">
          <li><a href="<?php echo base_url() ?>"><i class="icon-home"></i><span>Home</span> </a> </li>
          <?php if ($this->session->userdata('user')=='admin'): ?>
            <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-list"></i><span>Data</span> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo base_url('penyerapan_foc') ?>">Data Penyerapan Material FOC</a></li>
                <li><a href="<?php echo base_url('penyerapan_fot') ?>">Data Penyerapan Material FOT</a></li>
                <li><a href="<?php echo base_url('summary_stock_foc') ?>">Data Summary Stock FOC</a></li>
                <li><a href="<?php echo base_url('summary_stock_fot') ?>">Data Summary Stock FOT</a></li>
                <li><a href="<?php echo base_url('data_minimum_foc') ?>">Data Minimum FOC</a></li>
                <li><a href="<?php echo base_url('data_minimum_fot') ?>">Data Minimum FOT</a></li>
              </ul>
            </li>
          <?php endif ?>
          <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-bar-chart"></i><span>Report</span> <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="<?php echo base_url('penyerapan_foc/filter') ?>">Penyerapan Material FOC</a></li>
              <li><a href="<?php echo base_url('penyerapan_fot/filter') ?>">Penyerapan Material FOT</a></li>
              <li><a href="<?php echo base_url('summary_stock_foc/report') ?>">Summary Stock FOC</a></li>
                <li><a href="<?php echo base_url('summary_stock_fot/report') ?>">Summary Stock FOT</a></li>
            </ul>
          </li>
          <?php if ($this->session->userdata('user')=='admin'): ?>
            <li><a href="<?php echo base_url('login/logout') ?>"><i class="icon-signout"></i><span>Logout</span> </a> </li>
          <?php else: ?>
            <li><a href="<?php echo base_url('login') ?>"><i class="icon-signin"></i><span>Login</span> </a> </li>
          <?php endif ?>
        </ul>
      </div>
      <!-- /container --> 
    </div>
    <!-- /subnavbar-inner --> 
  </div>
  <!-- /subnavbar -->
  <div class="main" style="min-height: 600px">
    <div class="main-inner">
      <div class="container">
        <div class="row">
          <div class="span12">
            <?php echo $contents ?>
          </div>
        </div>
        <!-- /row --> 
      </div>
      <!-- /container --> 
    </div>
    <!-- /main-inner --> 
  </div>
  <!-- /main -->
  <div class="footer">
    <div class="footer-inner">
      <div class="container">
        <div class="row">
          <div class="span12"> &copy; 2019 <a href="#">PT INDONESIA COMNETS PLUS</a></div>
          <!-- /span12 --> 
        </div>
        <!-- /row --> 
      </div>
      <!-- /container --> 
    </div>
    <!-- /footer-inner --> 
  </div>
  <!-- /footer --> 
<!-- Le javascript
  ================================================== --> 
  <!-- Placed at the end of the document so the pages load faster --> 
  <script src="<?php echo base_url() ?>assets/js/excanvas.min.js"></script> 
  <script src="<?php echo base_url() ?>assets/js/bootstrap.js"></script>
  <script src="<?php echo base_url() ?>assets/js/base.js"></script> 

</body>
</html>
