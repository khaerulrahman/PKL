<center>
	<img src="<?php echo base_url('assets/img/pln.png') ?>" height="100px" width="100px" align="left">
	<img src="<?php echo base_url('assets/img/icon.jpg') ?>" height="150px" width="150px" align="right">
	<h1>Monitoring Stock dan Penyerapan Material Gudang</h1>
	<br>
</center>