<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Summary_stock_fot extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('PHPExcel');
		$this->load->model("phpexcel_model");
	}

	public function index()
	{
		$data = array(
			'no'     => 0,
			'judul'  => 'Data Summary Stock Fiber Optic Terminal',
			'add'    => base_url('summary_stock_fot/add'),
			'edit'   => base_url('summary_stock_fot/edit/'),
			'delete' => base_url('summary_stock_fot/delete/'),
			'query'  => $this->db->get('summary_stock_fot'), 
		);
		$this->template->load('template','summary_stock_fot/index',$data);
	}

	public function report($value='')
	{
		$data = array(
			'no'     => 0,
			'judul'  => 'Data Summary Stock Fiber Optic Terminal',
			'query'  => $this->db->get('summary_stock_fot'),
		);
		$this->template->load('template','summary_stock_fot/report',$data);
	}

	public function detail($material='')
    {
        $this->db->where('material', $material);
        $data = array(
            'no'     => 0,
            'judul'  => 'Data Summary Stock Fiber Optic Terminal',
            'query'  => $this->db->get('summary_stock_fot'),
        );
        $this->template->load('template','summary_stock_fot/detail',$data);
    }

	public function add()
	{
		$data = array(
			'action' => base_url('summary_stock_fot/save'),
			'judul'  => 'Data Summary Stock Fiber Optic Terminal',
		);
		$this->template->load('template','summary_stock_fot/upload',$data);
	}

	public function save()
	{
		$config['upload_path'] = './upload/';
		$config['allowed_types'] = 'xlsx|xls';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('filepenyerapan')) {
			echo "<script>alert('Gagal!');</script>";
			redirect(base_url('summary_stock_fot'),'refresh');
		} else {
            $this->db->truncate('summary_stock_fot');
			$data = array('upload_data' => $this->upload->data());
            $upload_data = $this->upload->data(); //Mengambil detail data yang di upload
            $filename = $upload_data['file_name'];//Nama File
            $this->phpexcel_model->upload_stock_fot($filename);
            unlink('./upload/'.$filename);
            redirect(base_url('summary_stock_fot'),'refresh');
        }
    }

    public function edit($id='')
    {
    	$this->db->where('id', $id);
    	$query = $this->db->get('summary_stock_fot');
    	foreach ($query->result() as $key) {
    		$data = array(
				'action'        => base_url('summary_stock_fot/update'),
				'judul'         => 'Data Summary Stock Fiber Optic Terminal',
				'id'            => $id, 
				'material'      => $key->material, 
				'material_desc' => $key->material_desc, 
				'jenis_kabel'   => $key->jenis_kabel, 
				'val_type'      => $key->val_type, 
				'movement'      => $key->movement, 
				'batch'         => $key->batch, 
				'mvt'           => $key->mvt, 
				'quantity'      => $key->quantity, 
				'posting_date'  => $key->posting_date, 
    		);
    	}
    	$this->template->load('template','summary_stock_fot/form',$data);
    }

    public function update()
    {
    	$id = $this->input->post('id');
    	$object = array(
			'material'      => $this->input->post('material'), 
			'material_desc' => $this->input->post('material_desc'),
			'jenis_kabel'   => $this->input->post('jenis_kabel'), 
			'val_type'      => $this->input->post('val_type'), 
			'movement'      => $this->input->post('movement'),
			'batch'         => $this->input->post('batch'),
			'mvt'           => $this->input->post('mvt'),
			'quantity'      => $this->input->post('quantity'),
			'posting_date'  => $this->input->post('posting_date'),
    	);
    	$this->db->where('id', $id);
    	$this->db->update('summary_stock_fot', $object);
    	redirect(base_url('summary_stock_fot'),'refresh');
    }

    public function delete($id='')
    {
    	$this->db->where('id', $id);
    	$this->db->delete('summary_stock_fot');
    	redirect(base_url('summary_stock_fot'),'refresh');
    }

}

/* End of file Summary_stock_fot.php */
/* Location: ./application/controllers/Summary_stock_fot.php */