<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penyerapan_foc extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('PHPExcel');
		$this->load->model("phpexcel_model");
	}

	public function index()
	{
		$data = array(
			'no'     => 0,
			'judul'  => 'Data Penyerapan Material Fiber Optic Cable',
			'add'    => base_url('penyerapan_foc/add'),
			'edit'   => base_url('penyerapan_foc/edit/'),
			'delete' => base_url('penyerapan_foc/delete/'),
			'query'  => $this->db->get('penyerapan_foc'), 
		);
		$this->template->load('template','penyerapan_foc/index',$data);
	}

    public function filter()
    {
        $data = array(
            'action' => base_url('penyerapan_foc/report'),
            'judul'  => 'Data Penyerapan Material Fiber Optic Cable',
        );
        $this->template->load('template','penyerapan_foc/filter',$data);
    }

	public function report($value='')
	{
        $from = $this->input->post('from');
        $to   = $this->input->post('to');
        $mvt  = $this->input->post('mvt');

		// $this->db->select('*, SUM(quantity) AS sum_quantity');

        if ($from != '') {
            $this->db->where('posting_date >=', $from);
        }
        if ($to != '') {
            $this->db->where('posting_date <=', $to);
        }
        if ($mvt != '') {
            $this->db->where('mvt', $mvt);
        }

		// $this->db->from('penyerapan_foc');
		// $this->db->group_by('material');
		// $this->db->order_by('jenis_kabel', 'asc');
        $query = $this->db->get('penyerapan_foc');

        if ($mvt == '') {
            $mvt = 0;
        }
        if ($from == '') {
            $from = 0;
        }
        if ($to == '') {
            $to = 0;
        }

		$data = array(
			'no'     => 0,
			'judul'  => 'Data Penyerapan Material Fiber Optic Cable',
			'query'  => $query,
            // 'excel'  => base_url('penyerapan_fot/excel/'),
            // 'detail' => base_url('penyerapan_fot/detail/'),
            'mvt'    => $mvt,
            'from'   => $from,
            'to'     => $to, 
		);
		$this->template->load('template','penyerapan_foc/report',$data);
	}

    public function detail($material='',$mvt='',$from='',$to='')
    {
        $this->db->where('material', $material);
        if ($mvt != 0) {
            $this->db->where('mvt', $mvt);
        }
        if ($from != 0) {
            $this->db->where('posting_date >=', $from);
        }
        if ($to != 0) {
            $this->db->where('posting_date <=', $to);
        }
        $data = array(
            'no'     => 0,
            'judul'  => 'Data Penyerapan Material Fiber Optic Cable',
            'query'  => $this->db->get('penyerapan_foc'),
        );
        $this->template->load('template','penyerapan_foc/detail',$data);
    }

	public function add()
	{
		$data = array(
			'action' => base_url('penyerapan_foc/save'),
			'judul'  => 'Data Penyerapan Material Fiber Optic Cable',
		);
		$this->template->load('template','penyerapan_foc/upload',$data);
	}

	public function save()
	{
		$config['upload_path'] = './upload/';
		$config['allowed_types'] = 'xlsx|xls';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('filepenyerapan')) {
			echo "<script>alert('Gagal!');</script>";
			redirect(base_url('penyerapan_foc'),'refresh');
		} else {
			$data = array('upload_data' => $this->upload->data());
            $upload_data = $this->upload->data(); //Mengambil detail data yang di upload
            $filename = $upload_data['file_name'];//Nama File
            $this->phpexcel_model->upload_data_foc($filename);
            unlink('./upload/'.$filename);
            redirect(base_url('penyerapan_foc'),'refresh');
        }
    }

    public function edit($id='')
    {
    	$this->db->where('id', $id);
    	$query = $this->db->get('penyerapan_foc');
    	foreach ($query->result() as $key) {
    		$data = array(
				'action'        => base_url('penyerapan_foc/update'),
				'judul'         => 'Data Penyerapan Material Fiber Optic Cable',
				'id'            => $id, 
				'material'      => $key->material, 
				'material_desc' => $key->material_desc, 
				'jenis_kabel'   => $key->jenis_kabel, 
				'val_type'      => $key->val_type, 
				'movement'      => $key->movement, 
				'batch'         => $key->batch, 
				'mvt'           => $key->mvt, 
				'quantity'      => $key->quantity, 
				'posting_date'  => $key->posting_date, 
    		);
    	}
    	$this->template->load('template','penyerapan_foc/form',$data);
    }

    public function update()
    {
    	$id = $this->input->post('id');
    	$object = array(
			'material'      => $this->input->post('material'), 
			'material_desc' => $this->input->post('material_desc'),
			'jenis_kabel'   => $this->input->post('jenis_kabel'), 
			'val_type'      => $this->input->post('val_type'), 
			'movement'      => $this->input->post('movement'),
			'batch'         => $this->input->post('batch'),
			'mvt'           => $this->input->post('mvt'),
			'quantity'      => $this->input->post('quantity'),
			'posting_date'  => $this->input->post('posting_date'),
    	);
    	$this->db->where('id', $id);
    	$this->db->update('penyerapan_foc', $object);
    	redirect(base_url('penyerapan_foc'),'refresh');
    }

    public function delete($id='')
    {
    	$this->db->where('id', $id);
    	$this->db->delete('penyerapan_foc');
    	redirect(base_url('penyerapan_foc'),'refresh');
    }

    public function excel()
    {
    	$this->load->helper('exportexcel');
    	$namaFile = "Data Penyerapan Material FOC";
    	$tablehead = 0;
    	$tablebody = 1;
    	$nourut = 1;
        //penulisan header
    	header("Pragma: public");
    	header("Expires: 0");
    	header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
    	header("Content-Type: application/force-download");
    	header("Content-Type: application/octet-stream");
    	header("Content-Type: application/download");
    	header("Content-Disposition: attachment;filename=" . $namaFile . "");
    	header("Content-Transfer-Encoding: binary ");

    	xlsBOF();

    	$kolomhead = 0;
    	xlsWriteLabel($tablehead, $kolomhead++, "No");
    	xlsWriteLabel($tablehead, $kolomhead++, "Material");
    	xlsWriteLabel($tablehead, $kolomhead++, "Material Description");
    	xlsWriteLabel($tablehead, $kolomhead++, "Quantity");

    	$this->db->select('*, SUM(quantity) AS sum_quantity');
    	$this->db->from('penyerapan_foc');
    	$this->db->group_by('material');
    	$query = $this->db->get();
    	foreach ($query->result() as $data) {
    		$kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
    		xlsWriteNumber($tablebody, $kolombody++, $nourut);
    		xlsWriteLabel($tablebody, $kolombody++, $data->material);
    		xlsWriteLabel($tablebody, $kolombody++, $data->material_desc);
    		xlsWriteLabel($tablebody, $kolombody++, $data->sum_quantity);

    		$tablebody++;
    		$nourut++;
    	}

    	xlsEOF();
    	exit();
    }

}

/* End of file Penyerapan_foc.php */
/* Location: ./application/controllers/Penyerapan_foc.php */