<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Summary_stock_foc extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('PHPExcel');
		$this->load->model("phpexcel_model");
	}

	public function index()
	{
		$data = array(
			'no'     => 0,
			'judul'  => 'Data Summary Stock Fiber Optic Cable',
			'add'    => base_url('summary_stock_foc/add'),
			'edit'   => base_url('summary_stock_foc/edit/'),
			'delete' => base_url('summary_stock_foc/delete/'),
			'query'  => $this->db->get('summary_stock_foc'), 
		);
		$this->template->load('template','summary_stock_foc/index',$data);
	}

	public function report($value='')
	{
		// $this->db->select('*, SUM(quantity) AS sum_quantity');
		// $this->db->from('summary_stock_foc');
		// $this->db->group_by('material');
		$data = array(
			'no'     => 0,
			'judul'  => 'Data Summary Stock Fiber Optic Cable',
			'query'  => $this->db->get('summary_stock_foc'),
			// 'excel'  => base_url('summary_stock_foc/excel/'),
            // 'detail' => base_url('summary_stock_foc/detail/'),  
		);
		$this->template->load('template','summary_stock_foc/report',$data);
	}

	public function detail($material='')
    {
        $this->db->where('material', $material);
        $data = array(
            'no'     => 0,
            'judul'  => 'Data Summary Stock Fiber Optic Cable',
            'query'  => $this->db->get('summary_stock_foc'),
        );
        $this->template->load('template','summary_stock_foc/detail',$data);
    }

	public function add()
	{
		$data = array(
			'action' => base_url('summary_stock_foc/save'),
			'judul'  => 'Data Summary Stock Fiber Optic Cable',
		);
		$this->template->load('template','summary_stock_foc/upload',$data);
	}

	public function save()
	{
		$config['upload_path'] = './upload/';
		$config['allowed_types'] = 'xlsx|xls';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('filepenyerapan')) {
			echo "<script>alert('Gagal!');</script>";
			redirect(base_url('summary_stock_foc'),'refresh');
		} else {
            $this->db->truncate('summary_stock_foc');
			$data = array('upload_data' => $this->upload->data());
            $upload_data = $this->upload->data(); //Mengambil detail data yang di upload
            $filename = $upload_data['file_name'];//Nama File
            $this->phpexcel_model->upload_stock_foc($filename);
            unlink('./upload/'.$filename);
            redirect(base_url('summary_stock_foc'),'refresh');
        }
    }

    public function edit($id='')
    {
    	$this->db->where('id', $id);
    	$query = $this->db->get('summary_stock_foc');
    	foreach ($query->result() as $key) {
    		$data = array(
				'action'        => base_url('summary_stock_foc/update'),
				'judul'         => 'Data Summary Stock Fiber Optic Cable',
				'id'            => $id, 
				'material'      => $key->material, 
				'material_desc' => $key->material_desc, 
				'jenis_kabel'   => $key->jenis_kabel, 
				'val_type'      => $key->val_type, 
				'movement'      => $key->movement, 
				'batch'         => $key->batch, 
				'mvt'           => $key->mvt, 
				'quantity'      => $key->quantity, 
				'posting_date'  => $key->posting_date, 
    		);
    	}
    	$this->template->load('template','summary_stock_foc/form',$data);
    }

    public function update()
    {
    	$id = $this->input->post('id');
    	$object = array(
			'material'      => $this->input->post('material'), 
			'material_desc' => $this->input->post('material_desc'),
			'jenis_kabel'   => $this->input->post('jenis_kabel'), 
			'val_type'      => $this->input->post('val_type'), 
			'movement'      => $this->input->post('movement'),
			'batch'         => $this->input->post('batch'),
			'mvt'           => $this->input->post('mvt'),
			'quantity'      => $this->input->post('quantity'),
			'posting_date'  => $this->input->post('posting_date'),
    	);
    	$this->db->where('id', $id);
    	$this->db->update('summary_stock_foc', $object);
    	redirect(base_url('summary_stock_foc'),'refresh');
    }

    public function delete($id='')
    {
    	$this->db->where('id', $id);
    	$this->db->delete('summary_stock_foc');
    	redirect(base_url('summary_stock_foc'),'refresh');
    }

}

/* End of file Summary_stock_foc.php */
/* Location: ./application/controllers/Summary_stock_foc.php */