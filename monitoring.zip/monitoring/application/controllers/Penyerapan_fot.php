<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penyerapan_fot extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('PHPExcel');
		$this->load->model("phpexcel_model");
	}

	public function index()
	{
		$data = array(
			'no'     => 0,
			'judul'  => 'Data Penyerapan Material Fiber Optic Terminal',
			'add'    => base_url('penyerapan_fot/add'),
			'edit'   => base_url('penyerapan_fot/edit/'),
			'delete' => base_url('penyerapan_fot/delete/'),
			'query'  => $this->db->get('penyerapan_fot'), 
		);
		$this->template->load('template','penyerapan_fot/index',$data);
	}

    public function filter()
    {
        $data = array(
            'action' => base_url('penyerapan_fot/report'),
            'judul'  => 'Data Penyerapan Material Fiber Optic Terminal',
        );
        $this->template->load('template','penyerapan_fot/filter',$data);
    }

	public function report($value='')
	{
        $from = $this->input->post('from');
        $to   = $this->input->post('to');
        $mvt  = $this->input->post('mvt');

		// $this->db->select('*, SUM(quantity) AS sum_quantity');

        if ($from != '') {
            $this->db->where('posting_date >=', $from);
        }
        if ($to != '') {
            $this->db->where('posting_date <=', $to);
        }
        if ($mvt != '') {
            $this->db->where('mvt', $mvt);
        }

		// $this->db->from('penyerapan_fot');
		// $this->db->group_by('material');
        $query = $this->db->get('penyerapan_fot');

        if ($mvt == '') {
            $mvt = 0;
        }
        if ($from == '') {
            $from = 0;
        }
        if ($to == '') {
            $to = 0;
        }

        $data  = array(
            'no'     => 0,
            'judul'  => 'Data Penyerapan Material Fiber Optic Terminal',
            'query'  => $query, 
            // 'excel'  => base_url('penyerapan_fot/excel/'),
            // 'detail' => base_url('penyerapan_fot/detail/'),
            'mvt'    => $mvt,
            'from'   => $from,
            'to'     => $to,
		);
		$this->template->load('template','penyerapan_fot/report',$data);
	}

	public function detail($material='',$mvt='',$from='',$to='')
	{
		$this->db->where('material', $material);
        if ($mvt != 0) {
            $this->db->where('mvt', $mvt);
        }
        if ($from != 0) {
            $this->db->where('posting_date >=', $from);
        }
        if ($to != 0) {
            $this->db->where('posting_date <=', $to);
        }
		$data = array(
			'no'     => 1,
			'judul'  => 'Data Penyerapan Material Fiber Optic Terminal',
			'query'  => $this->db->get('penyerapan_fot'),
		);
		$this->template->load('template','penyerapan_fot/detail',$data);
	}

	public function add()
	{
		$data = array(
			'action' => base_url('penyerapan_fot/save'),
			'judul'  => 'Data Penyerapan Material Fiber Optic Terminal',
		);
		$this->template->load('template','penyerapan_fot/upload',$data);
	}

	public function save()
	{
		$config['upload_path'] = './upload/';
		$config['allowed_types'] = 'xlsx|xls';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('filepenyerapan')) {
			echo "<script>alert('Gagal!');</script>";
			redirect(base_url('penyerapan_fot'),'refresh');
		} else {
			$data = array('upload_data' => $this->upload->data());
            $upload_data = $this->upload->data(); //Mengambil detail data yang di upload
            $filename = $upload_data['file_name'];//Nama File
            $this->phpexcel_model->upload_data_fot($filename);
            unlink('./upload/'.$filename);
            redirect(base_url('penyerapan_fot'),'refresh');
        }
    }

    public function edit($id='')
    {
    	$this->db->where('id', $id);
    	$query = $this->db->get('penyerapan_fot');
    	foreach ($query->result() as $key) {
    		$data = array(
    			'action'        => base_url('penyerapan_fot/update'),
    			'judul'         => 'Data Penyerapan Material Fiber Optic Terminal',
    			'id'            => $id, 
    			'material'      => $key->material, 
    			'material_desc' => $key->material_desc, 
    			'val_type'      => $key->val_type, 
    			'movement'      => $key->movement, 
    			'mvt'           => $key->mvt, 
    			'quantity'      => $key->quantity, 
    			'posting_date'  => $key->posting_date, 
    		);
    	}
    	$this->template->load('template','penyerapan_fot/form',$data);
    }

    public function update()
    {
    	$id = $this->input->post('id');
    	$object = array(
    		'material'      => $this->input->post('material'), 
    		'material_desc' => $this->input->post('material_desc'),
    		'val_type'      => $this->input->post('val_type'), 
    		'movement'      => $this->input->post('movement'),
    		'mvt'           => $this->input->post('mvt'),
    		'quantity'      => $this->input->post('quantity'),
    		'posting_date'  => $this->input->post('posting_date'),
    	);
    	$this->db->where('id', $id);
    	$this->db->update('penyerapan_fot', $object);
    	redirect(base_url('penyerapan_fot'),'refresh');
    }

    public function delete($id='')
    {
    	$this->db->where('id', $id);
    	$this->db->delete('penyerapan_fot');
    	redirect(base_url('penyerapan_fot'),'refresh');
    }

    public function excel()
    {
    	$this->load->helper('exportexcel');
        $namaFile  = "Data Penyerapan Material FOT.xls";
        $tablehead = 0;
        $tablebody = 1;
        $nourut    = 1;
        //penulisan header
    	header("Pragma: public");
    	header("Expires: 0");
    	header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
    	header("Content-Type: application/force-download");
    	header("Content-Type: application/octet-stream");
    	header("Content-Type: application/download");
    	header("Content-Disposition: attachment;filename=" . $namaFile . "");
    	header("Content-Transfer-Encoding: binary ");

    	xlsBOF();

    	$kolomhead = 0;
    	xlsWriteLabel($tablehead, $kolomhead++, "No");
    	xlsWriteLabel($tablehead, $kolomhead++, "Material");
    	xlsWriteLabel($tablehead, $kolomhead++, "Material Description");
        xlsWriteLabel($tablehead, $kolomhead++, "Val. Type");
        xlsWriteLabel($tablehead, $kolomhead++, "Movement Type Text");
        xlsWriteLabel($tablehead, $kolomhead++, "Order");
        xlsWriteLabel($tablehead, $kolomhead++, "Mvt");
        xlsWriteLabel($tablehead, $kolomhead++, "Text");
        xlsWriteLabel($tablehead, $kolomhead++, "Quantity");
    	xlsWriteLabel($tablehead, $kolomhead++, "Posting Date");

    	// $this->db->select('*, SUM(quantity) AS sum_quantity');
    	// $this->db->from('penyerapan_fot');
    	// $this->db->group_by('material');
    	$query = $this->db->get('penyerapan_fot');
    	foreach ($query->result() as $data) {
    		$kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
    		xlsWriteNumber($tablebody, $kolombody++, $nourut);
    		xlsWriteLabel($tablebody, $kolombody++, $data->material);
    		xlsWriteLabel($tablebody, $kolombody++, $data->material_desc);
            xlsWriteLabel($tablebody, $kolombody++, $data->val_type);
            xlsWriteLabel($tablebody, $kolombody++, $data->movement);
            xlsWriteLabel($tablebody, $kolombody++, $data->orderr);
            xlsWriteLabel($tablebody, $kolombody++, $data->mvt);
            xlsWriteLabel($tablebody, $kolombody++, $data->text);
            xlsWriteLabel($tablebody, $kolombody++, $data->quantity);
    		xlsWriteLabel($tablebody, $kolombody++, $data->posting_date);

    		$tablebody++;
    		$nourut++;
    	}

    	xlsEOF();
    	exit();
    }

}

/* End of file Penyerapan_fot.php */
/* Location: ./application/controllers/Penyerapan_fot.php */