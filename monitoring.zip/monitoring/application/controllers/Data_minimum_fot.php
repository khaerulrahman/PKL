<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_minimum_fot extends CI_Controller {

	public function index()
	{
		$this->db->where('jenis', 'fot');
		$data = array(
			'no'     => 0,
			'judul'  => 'Data Minimum Stock Fiber Optic Terminal',
			'add'    => base_url('data_minimum_fot/add'),
			'edit'   => base_url('data_minimum_fot/edit/'),
			'delete' => base_url('data_minimum_fot/delete/'),
			'query'  => $this->db->get('minimum_stock'), 
		);
		$this->template->load('template','data_minimum_fot/index',$data);
	}

	public function add()
	{
		$data = array(
			'action' => base_url('data_minimum_fot/save'),
			'read'   => 'required',
			'judul'  => 'Data Minimum Stock Fiber Optic Terminal',
			'material'      => '', 
			'material_desc' => '', 
			'minimum_stock'      => '',
		);
		$this->template->load('template','data_minimum_fot/form',$data);
	}

	public function save()
	{
		$object = array(
			'material'      => $this->input->post('material'), 
			'material_desc' => $this->input->post('material_desc'), 
			'minimum_stock'      => $this->input->post('minimum_stock'),
			'jenis'         => 'fot', 
		);
		$this->db->insert('minimum_stock', $object);
    	redirect(base_url('data_minimum_fot'),'refresh');
    }

    public function edit($id='')
    {
    	$this->db->where('material', $id);
    	$query = $this->db->get('minimum_stock');
    	foreach ($query->result() as $key) {
    		$data = array(
				'action'        => base_url('data_minimum_fot/update'),
				'read'          => 'readonly',
				'judul'         => 'Data Minimum Stock Fiber Optic Terminal',
				'material'      => $key->material, 
				'material_desc' => $key->material_desc, 
				'minimum_stock'      => $key->minimum_stock,
    		);
    	}
    	$this->template->load('template','data_minimum_fot/form',$data);
    }

    public function update()
    {
    	$material = $this->input->post('material');
    	$object = array(
			'material_desc' => $this->input->post('material_desc'),
			'minimum_stock'      => $this->input->post('minimum_stock'),
    	);
    	$this->db->where('material', $material);
    	$this->db->update('minimum_stock', $object);
    	redirect(base_url('data_minimum_fot'),'refresh');
    }

    public function delete($id='')
    {
    	$this->db->where('material', $id);
    	$this->db->delete('minimum_stock');
    	redirect(base_url('data_minimum_fot'),'refresh');
    }

}

/* End of file Data_minimum_fot.php */
/* Location: ./application/controllers/Data_minimum_fot.php */