<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('pdf');
		$this->load->library('pdf_wrap');
		$this->load->helper('rupiah');
	}

	public function index()
	{
		
	}

	public function obat($id='')
	{
		$pdf = new FPDF('l','mm','A4');
		$pdf->AddPage();
		// $pdf->SetFillColor(133, 209, 252);
		$pdf->SetFont('Arial','B',16);
		$pdf->Image(base_url('assets/img/logo.jpeg'),1,2,70,20);
		$pdf->SetFont("", "B", 13);
		$pdf->Cell(0,7,'Laporan Data Obat',0,1,'C');
		$pdf->SetFont("", "", 11);
		$pdf->Cell(0,7,'Jl. Vetran Simpang SMP 7 Jalur 3 No. 8/10 RT 34 Banjarmasin',0,1,'C');
		$pdf->Cell(0,7,'Telp: 0511 7558599',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetFont('','B',10);
		$pdf->Cell(10,6,'NO',1,0,'C');
		$pdf->Cell(30,6,'Kode Obat',1,0,'C');
		$pdf->Cell(50,6,'Golongan Obat',1,0,'C');
		$pdf->Cell(30,6,'Jenis Obat',1,0,'C');
		$pdf->Cell(30,6,'Nama Obat',1,0,'C');
		$pdf->Cell(30,6,'Harga Beli',1,0,'C');
		$pdf->Cell(30,6,'Harga Jual',1,0,'C');
		$pdf->Cell(30,6,'Kadaluarsa',1,0,'C');
		$pdf->Cell(30,6,'Satuan',1,1,'C');
		if ($id!='') {
			$this->db->where('kode_obat', $id);
		}
		$data = $this->db->get('obat')->result();
		$no   = 1;
		$pdf->SetFont('','',10);
		foreach ($data as $key) {
			$pdf->Cell(10,6,$no,1,0,'C');
			$pdf->Cell(30,6,$key->kode_obat,1,0,'C');
			$pdf->Cell(50,6,$key->golongan_obat,1,0,'');
			$pdf->Cell(30,6,$key->jenis_obat,1,0,'');
			$pdf->Cell(30,6,$key->nama_obat,1,0,'');
			$pdf->Cell(30,6,$key->harga_beli,1,0,'');
			$pdf->Cell(30,6,$key->harga_jual,1,0,'');
			$pdf->Cell(30,6,$key->kadaluarsa,1,0,'');
			$pdf->Cell(30,6,$key->satuan,1,1,'');
			$no++;
		}
		$pdf->SetLeftMargin(150);
		$pdf->Ln(10);
		$pdf->SetFont('','',12);
		$pdf->Cell(0,7,'Banjramasin,   Agustus 2019',0,1,'C');
		$pdf->Cell(0,7,'Penanggung Jawab',0,1,'C');
		$pdf->Ln(20);
		$pdf->Cell(0,7,'...................',0,1,'C');
		$pdf->Output();
	}

	public function stok($id='')
	{
		$pdf = new FPDF('p','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Image(base_url('assets/img/logo.jpeg'),1,2,70,20);
		$pdf->SetFont("", "B", 13);
		$pdf->Cell(0,7,'Laporan Data Stok Obat',0,1,'C');
		$pdf->SetFont("", "", 11);
		$pdf->Cell(0,7,'Jl. Vetran Simpang SMP 7 Jalur 3 No. 8/10 RT 34 Banjarmasin',0,1,'C');
		$pdf->Cell(0,7,'Telp: 0511 7558599',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetLeftMargin(40);
		$pdf->SetFont('','B',10);
		$pdf->Cell(10,6,'NO',1,0,'C');
		$pdf->Cell(30,6,'Kode Obat',1,0,'C');
		$pdf->Cell(30,6,'Nama Obat',1,0,'C');
		$pdf->Cell(30,6,'Kadaluarsa',1,0,'C');
		$pdf->Cell(30,6,'Sisa Persediaan',1,1,'C');
		$this->db->select('*');
		$this->db->from('stok');
		$this->db->join('obat', 'obat.kode_obat = stok.kode_obat', 'left');
		if ($id!='') {
			$this->db->where('id', $id);
		}
		$data = $this->db->get()->result();
		$no   = 1;
		$pdf->SetFont('','',10);
		foreach ($data as $key) {
			$pdf->Cell(10,6,$no,1,0,'C');
			$pdf->Cell(30,6,$key->kode_obat,1,0,'');
			$pdf->Cell(30,6,$key->nama_obat,1,0,'');
			$pdf->Cell(30,6,$key->kadaluarsa,1,0,'');
			$pdf->Cell(30,6,$key->sisa_persediaan,1,1,'');
			$no++;
		}
		$pdf->SetLeftMargin(150);
		$pdf->Ln(10);
		$pdf->SetFont('','',9);
		$pdf->Cell(0,7,'Banjramasin,   Agustus 2019',0,1,'C');
		$pdf->Cell(0,7,'Penanggung Jawab',0,1,'C');
		$pdf->Ln(20);
		$pdf->Cell(0,7,'...................',0,1,'C');
		$pdf->Output();
	}	

	public function pelanggan($id='')
	{
		$pdf = new FPDF('l','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Image(base_url('assets/img/logo.jpeg'),1,2,70,20);
		$pdf->SetFont("", "B", 13);
		$pdf->SetLeftMargin(2);
		$pdf->Cell(0,7,'Laporan Data Pelanggan',0,1,'C');
		$pdf->SetFont("", "", 11);
		$pdf->Cell(0,7,'Jl. Vetran Simpang SMP 7 Jalur 3 No. 8/10 RT 34 Banjarmasin',0,1,'C');
		$pdf->Cell(0,7,'Telp: 0511 7558599',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetFont('','B',10);
		$pdf->Cell(10,6,'NO',1,0,'C');
		$pdf->Cell(15,6,'Kode',1,0,'C');
		$pdf->Cell(35,6,'Nama Pelanggan',1,0,'C');
		$pdf->Cell(50,6,'Alamat',1,0,'C');
		$pdf->Cell(25,6,'Telpon',1,0,'C');
		$pdf->Cell(30,6,'Kota',1,0,'C');
		$pdf->Cell(30,6,'Pemilik Apotik',1,0,'C');
		$pdf->Cell(30,6,'Apotik',1,0,'C');
		$pdf->Cell(30,6,'Telp Apotik',1,0,'C');
		$pdf->Cell(30,6,'No Izin',1,1,'C');
		if ($id!='') {
			$this->db->where('kode_pelanggan', $id);
		}
		$data = $this->db->get('pelanggan')->result();
		$no   = 1;
		$pdf->SetFont('','',10);
		foreach ($data as $key) {
			$pdf->Cell(10,6,$no,1,0,'C');
			$pdf->Cell(15,6,$key->kode_pelanggan,1,0,'');
			$pdf->Cell(35,6,$key->nama_pelanggan,1,0,'');
			$pdf->Cell(50,6,$key->alamat,1,0,'');
			$pdf->Cell(25,6,$key->telpon,1,0,'');
			$pdf->Cell(30,6,$key->kota,1,0,'');
			$pdf->Cell(30,6,$key->nama_pemilik,1,0,'');
			$pdf->Cell(30,6,$key->nama_apotik,1,0,'');
			$pdf->Cell(30,6,$key->telp_apotik,1,0,'');
			$pdf->Cell(30,6,$key->no_izin,1,1,'');
			$no++;
		}
		$pdf->SetLeftMargin(150);
		$pdf->Ln(10);
		$pdf->SetFont('','',12);
		$pdf->Cell(0,7,'Banjramasin,   Agustus 2019',0,1,'C');
		$pdf->Cell(0,7,'Penanggung Jawab',0,1,'C');
		$pdf->Ln(20);
		$pdf->Cell(0,7,'...................',0,1,'C');
		$pdf->Output();
	}

	public function pegawai($id='')
	{
		$pdf = new FPDF('l','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Image(base_url('assets/img/logo.jpeg'),1,2,70,20);
		$pdf->SetFont("", "B", 13);
		$pdf->Cell(0,7,'Laporan Data Pegawai',0,1,'C');
		$pdf->SetFont("", "", 11);
		$pdf->Cell(0,7,'Jl. Vetran Simpang SMP 7 Jalur 3 No. 8/10 RT 34 Banjarmasin',0,1,'C');
		$pdf->Cell(0,7,'Telp: 0511 7558599',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetLeftMargin(20);
		$pdf->SetFont('','B',10);
		$pdf->Cell(10,6,'NO',1,0,'C');
		$pdf->Cell(30,6,'Kode pegawai',1,0,'C');
		$pdf->Cell(80,6,'Nama pegawai',1,0,'C');
		$pdf->Cell(100,6,'Alamat',1,0,'C');
		$pdf->Cell(30,6,'Telpon',1,1,'C');
		if ($id!='') {
			$this->db->where('kode_pegawai', $id);
		}
		$data = $this->db->get('pegawai')->result();
		$no   = 1;
		$pdf->SetFont('','',10);
		foreach ($data as $key) {
			$pdf->Cell(10,6,$no,1,0,'C');
			$pdf->Cell(30,6,$key->kode_pegawai,1,0,'');
			$pdf->Cell(80,6,$key->nama_pegawai,1,0,'');
			$pdf->Cell(100,6,$key->alamat,1,0,'');
			$pdf->Cell(30,6,$key->telpon,1,1,'');
			$no++;
		}
		$pdf->SetLeftMargin(150);
		$pdf->Ln(10);
		$pdf->SetFont('','',12);
		$pdf->Cell(0,7,'Banjramasin,   Agustus 2019',0,1,'C');
		$pdf->Cell(0,7,'Penanggung Jawab',0,1,'C');
		$pdf->Ln(20);
		$pdf->Cell(0,7,'...................',0,1,'C');
		$pdf->Output();
	}

	public function pemasok($id='')
	{
		$pdf = new FPDF('l','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Image(base_url('assets/img/logo.jpeg'),1,2,70,20);
		$pdf->SetFont("", "B", 13);
		$pdf->Cell(0,7,'Laporan Data Pemasok',0,1,'C');
		$pdf->SetFont("", "", 11);
		$pdf->Cell(0,7,'Jl. Vetran Simpang SMP 7 Jalur 3 No. 8/10 RT 34 Banjarmasin',0,1,'C');
		$pdf->Cell(0,7,'Telp: 0511 7558599',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetFont('','B',10);
		$pdf->Cell(10,6,'NO',1,0,'C');
		$pdf->Cell(30,6,'Kode Pemasok',1,0,'C');
		$pdf->Cell(80,6,'Nama Pemasok',1,0,'C');
		$pdf->Cell(100,6,'Alamat',1,0,'C');
		$pdf->Cell(30,6,'Telpon',1,0,'C');
		$pdf->Cell(30,6,'Kota',1,1,'C');
		if ($id!='') {
			$this->db->where('kode_pemasok', $id);
		}
		$data = $this->db->get('pemasok')->result();
		$no   = 1;
		$pdf->SetFont('','',10);
		foreach ($data as $key) {
			$pdf->Cell(10,6,$no,1,0,'C');
			$pdf->Cell(30,6,$key->kode_pemasok,1,0,'');
			$pdf->Cell(80,6,$key->nama_pemasok,1,0,'');
			$pdf->Cell(100,6,$key->alamat,1,0,'');
			$pdf->Cell(30,6,$key->telpon,1,0,'');
			$pdf->Cell(30,6,$key->kota,1,1,'');
			$no++;
		}
		$pdf->SetLeftMargin(150);
		$pdf->Ln(10);
		$pdf->SetFont('','',12);
	$pdf->Cell(0,7,'Banjramasin,   Agustus 2019',0,1,'C');
		$pdf->Cell(0,7,'Penanggung Jawab',0,1,'C');
		$pdf->Ln(20);
		$pdf->Cell(0,7,'...................',0,1,'C');
		$pdf->Output();
	}

	public function penjualan($id='')
	{
		$pdf = new FPDF('l','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Image(base_url('assets/img/logo.jpeg'),1,2,70,20);
		$pdf->SetFont("", "B", 13);
		$pdf->Cell(0,7,'Laporan Data Penjualan',0,1,'C');
		$pdf->SetFont("", "", 11);
		$pdf->Cell(0,7,'Jl. Vetran Simpang SMP 7 Jalur 3 No. 8/10 RT 34 Banjarmasin',0,1,'C');
		$pdf->Cell(0,7,'Telp: 0511 7558599',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetFont('','B',10);
		$pdf->Cell(10,6,'NO',1,0,'C');
		$pdf->Cell(25,6,'No Transaksi',1,0,'C');
		$pdf->Cell(30,6,'Obat',1,0,'C');
		$pdf->Cell(55,6,'Pegawai',1,0,'C');
		$pdf->Cell(55,6,'Pelanggan',1,0,'C');
		$pdf->Cell(20,6,'Tanggal',1,0,'C');
		$pdf->Cell(20,6,'Harga Jual',1,0,'C');
		$pdf->Cell(20,6,'Jumlah',1,0,'C');
		$pdf->Cell(20,6,'Total',1,0,'C');
		$pdf->Cell(25,6,'Status',1,1,'C');
		$this->db->select('*');
		$this->db->from('penjualan');
		$this->db->join('obat', 'obat.kode_obat = penjualan.kode_obat', 'left');
		$this->db->join('pegawai', 'pegawai.kode_pegawai = penjualan.kode_pegawai', 'left');
		$this->db->join('pelanggan', 'pelanggan.kode_pelanggan = penjualan.kode_pelanggan', 'left');
		if ($id!='') {
			$this->db->where('no_tran', $id);
		}
		$data = $this->db->get()->result();
		$no   = 1;
		$pdf->SetFont('','',10);
		foreach ($data as $key) {
			$pdf->Cell(10,6,$no,1,0,'C');
			$pdf->Cell(25,6,$key->no_tran,1,0,'');
			$pdf->Cell(30,6,$key->nama_obat,1,0,'');
			$pdf->Cell(55,6,$key->nama_pegawai,1,0,'');
			$pdf->Cell(55,6,$key->nama_pelanggan,1,0,'');
			$pdf->Cell(20,6,$key->tgl,1,0,'');
			$pdf->Cell(20,6,$key->harga_jual,1,0,'');
			$pdf->Cell(20,6,$key->jumlah,1,0,'');
			$pdf->Cell(20,6,$key->total,1,0,'');
			$pdf->Cell(25,6,$key->status,1,1,'');
			$no++;
		}
		$pdf->SetLeftMargin(150);
		$pdf->Ln(10);
		$pdf->SetFont('','',12);
		$pdf->Cell(0,7,'Banjramasin,   Agustus 2019',0,1,'C');
		$pdf->Cell(0,7,'Penanggung Jawab',0,1,'C');
		$pdf->Ln(20);
		$pdf->Cell(0,7,'...................',0,1,'C');
		$pdf->Output();
	}

	public function pemesanan($id='')
	{
		$pdf = new FPDF('l','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Image(base_url('assets/img/logo.jpeg'),1,2,70,20);
		$pdf->SetFont("", "B", 13);
		$pdf->Cell(0,7,'Laporan Data Pemesanan',0,1,'C');
		$pdf->SetFont("", "", 11);
		$pdf->Cell(0,7,'Jl. Vetran Simpang SMP 7 Jalur 3 No. 8/10 RT 34 Banjarmasin',0,1,'C');
		$pdf->Cell(0,7,'Telp: 0511 7558599',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetLeftMargin(20);
		$pdf->SetFont('','B',10);
		$pdf->Cell(10,6,'NO',1,0,'C');
		$pdf->Cell(30,6,'No Pemesanan',1,0,'C');
		$pdf->Cell(40,6,'Nama Obat',1,0,'C');
		$pdf->Cell(80,6,'Nama pemasok',1,0,'C');
		$pdf->Cell(30,6,'Tanggal',1,0,'C');
		$pdf->Cell(20,6,'Harga',1,0,'C');
		$pdf->Cell(20,6,'Jumlah',1,0,'C');
		$pdf->Cell(20,6,'Total',1,1,'C');
		$this->db->select('*');
		$this->db->from('pemesanan');
		$this->db->join('obat', 'obat.kode_obat = pemesanan.kode_obat', 'left');
		$this->db->join('pemasok', 'pemasok.kode_pemasok = pemesanan.kode_pemasok', 'left');
		if ($id!='') {
			$this->db->where('no_pemesanan', $id);
		}
		$data = $this->db->get()->result();
		$no   = 1;
		$pdf->SetFont('','',10);
		foreach ($data as $key) {
			$pdf->Cell(10,6,$no,1,0,'C');
			$pdf->Cell(30,6,$key->no_pemesanan,1,0,'');
			$pdf->Cell(40,6,$key->nama_obat,1,0,'');
			$pdf->Cell(80,6,$key->nama_pemasok,1,0,'');
			$pdf->Cell(30,6,$key->tgl,1,0,'');
			$pdf->Cell(20,6,$key->harga,1,0,'');
			$pdf->Cell(20,6,$key->jumlah,1,0,'');
			$pdf->Cell(20,6,$key->total,1,1,'');
			$no++;
		}
		$pdf->SetLeftMargin(150);
		$pdf->Ln(10);
		$pdf->SetFont('','',12);
		$pdf->Cell(0,7,'Banjramasin,   Agustus 2019',0,1,'C');
		$pdf->Cell(0,7,'Penanggung Jawab',0,1,'C');
		$pdf->Ln(20);
		$pdf->Cell(0,7,'...................',0,1,'C');
		$pdf->Output();
	}

	public function pengembalian($id='')
	{
		$pdf = new FPDF('l','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Image(base_url('assets/img/logo.jpeg'),1,2,70,20);
		$pdf->SetFont("", "B", 13);
		$pdf->Cell(0,7,'Laporan Data Pengembalian',0,1,'C');
		$pdf->SetFont("", "", 11);
		$pdf->Cell(0,7,'Jl. Vetran Simpang SMP 7 Jalur 3 No. 8/10 RT 34 Banjarmasin',0,1,'C');
		$pdf->Cell(0,7,'Telp: 0511 7558599',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetLeftMargin(45);
		$pdf->SetFont('','B',10);
		$pdf->Cell(10,6,'NO',1,0,'C');
		$pdf->Cell(25,6,'No Transaksi',1,0,'C');
		$pdf->Cell(40,6,'Nama Obat',1,0,'C');
		$pdf->Cell(80,6,'Nama Pelanggan',1,0,'C');
		$pdf->Cell(30,6,'Tanggal Kembali',1,0,'C');
		$pdf->Cell(20,6,'Jumlah',1,1,'C');
		
		$this->db->select('*');
		$this->db->from('pengembalian');
		$this->db->join('obat', 'obat.kode_obat = pengembalian.kode_obat', 'left');
		$this->db->join('pelanggan', 'pelanggan.kode_pelanggan = pengembalian.kode_pelanggan', 'left');
		if ($id!='') {
			$this->db->where('no_tran', $id);
		}
		$data = $this->db->get()->result();
		$no   = 1;
		$pdf->SetFont('','',10);
		foreach ($data as $key) {
			$pdf->Cell(10,6,$no,1,0,'C');
			$pdf->Cell(25,6,$key->no_tran,1,0,'C');
			$pdf->Cell(40,6,$key->nama_obat,1,0,'');
			$pdf->Cell(80,6,$key->nama_pelanggan,1,0,'');
			$pdf->Cell(30,6,$key->tgl_kembali,1,0,'');
			$pdf->Cell(20,6,$key->jumlah,1,1,'');
			
			$no++;
		}
		$pdf->SetLeftMargin(150);
		$pdf->Ln(10);
		$pdf->SetFont('','',12);
		$pdf->Cell(0,7,'Banjramasin,   Agustus 2019',0,1,'C');
		$pdf->Cell(0,7,'Penanggung Jawab',0,1,'C');
		$pdf->Ln(20);
		$pdf->Cell(0,7,'...................',0,1,'C');
		$pdf->Output();
	}

	public function invoice($id='')
	{
		$this->db->select('*, penjualan.harga_jual as jual');
		$this->db->from('penjualan');
		$this->db->join('obat', 'obat.kode_obat = penjualan.kode_obat', 'left');
		$this->db->join('pegawai', 'pegawai.kode_pegawai = penjualan.kode_pegawai', 'left');
		$this->db->join('pelanggan', 'pelanggan.kode_pelanggan = penjualan.kode_pelanggan', 'left');
		$this->db->where('no_tran', $id);
		$data = $this->db->get();
		foreach ($data->result() as $key) {
			$banyaknya      = $key->jumlah;
			$satuan         = $key->satuan;
			$nama_obat      = $key->nama_obat;
			$harga_satuan   = $key->jual;
			$total          = $key->total;
			$tgl            = $key->tgl;
			$nama_pelanggan = $key->nama_pelanggan;
			$nama_pegawai   = $key->nama_pegawai;
		}

		$pdf = new FPDF('p','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','',11);
		$pdf->Cell(50,7,'PT. SAWAH BESAR FARMA',0,0,'');
		$pdf->Cell(80,7,'',0,0,'');
		$pdf->Cell(30,7,'No Transaksi : ',0,0,'R');
		$pdf->Cell(30,7,$id,0,1,'');
		$pdf->Cell(50,7,'Jl. Vetran Simpang SMP 7 Jalur 3',0,0,'');
		$pdf->Cell(80,7,'',0,0,'');
		$pdf->Cell(30,7,'Kepada : ',0,0,'R');
		$pdf->Cell(30,7,$nama_pelanggan,0,1,'');
		$pdf->Cell(0,7,'No. 8/10 RT 34 Banjarmasin',0,1,'');
		$pdf->SetFont('','B',12);
		$pdf->Cell(0,7,'INVOICE',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetLeftMargin(25);
		$pdf->SetFont('','B',10);
		$pdf->Cell(40,6,'Banyaknya',1,0,'C');
		$pdf->Cell(40,6,'Nama Obat',1,0,'C');
		$pdf->Cell(40,6,'Harga Satuan',1,0,'C');
		$pdf->Cell(40,6,'Jumlah',1,1,'C');
		
		$pdf->SetFont('','',10);
		$pdf->Cell(40,6,$banyaknya.' '.$satuan,1,0,'');
		$pdf->Cell(40,6,$nama_obat,1,0,'');
		$pdf->Cell(40,6,rupiah($harga_satuan),1,0,'');
		$pdf->Cell(40,6,rupiah($total),1,1,'');
			
		$tgl = date_create($tgl);
		$tgl = date_format($tgl,'d-m-Y');
		$pdf->Cell(40,6,'',0,0,'');
		$pdf->Cell(40,6,'',0,0,'');
		$pdf->Cell(40,6,'Total',1,0,'C');
		$pdf->Cell(40,6,rupiah($total),1,1,'');
		$pdf->Ln(30);

		$pdf->Cell(80,6,'',0,0,'');
		$pdf->Cell(80,6,'Hormat Kami',0,1,'C');
		$pdf->Cell(80,6,'',0,0,'');
		$pdf->Cell(80,6,'Banjarmasin, '.$tgl,0,1,'C');
		$pdf->Ln(20);
		$pdf->Cell(80,6,'',0,0,'');
		$pdf->Cell(80,6,$nama_pegawai,0,1,'C');
		
		$pdf->Output();

	}
	
	 
	public function siswa($id='')
	{
		$pdf = new FPDF('l','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Image(base_url('assets/img/logo.jpeg'),1,2,70,20);
		$pdf->SetFont("", "B", 13);
		$pdf->Cell(0,7,'Laporan Data Siswa',0,1,'C');
		$pdf->SetFont("", "", 11);
		$pdf->Cell(0,7,'Jl. Vetran Simpang SMP 7 Jalur 3 No. 8/10 RT 34 Banjarmasin',0,1,'C');
		$pdf->Cell(0,7,'Telp: 0511 7558599',0,1,'C');
		$pdf->Ln(5);
		$pdf->Cell(0, 1, " ", "B");
		$pdf->Ln(5);
		$pdf->SetFont('','B',10);
		$pdf->Cell(10,6,'NO',1,0,'C');
		$pdf->Cell(30,6,'Nik',1,0,'C');
		$pdf->Cell(80,6,'Nama',1,0,'C');
		$pdf->Cell(100,6,'Alamat',1,0,'C');
		$pdf->Cell(30,6,'Telpon',1,1,'C');
		if ($id!='') {
			$this->db->where('nik', $id);
		}
		$data = $this->db->get('siswa')->result();
		$no   = 1;
		$pdf->SetFont('','',10);
		foreach ($data as $key) {
			$pdf->Cell(10,6,$no,1,0,'C');
			$pdf->Cell(30,6,$key->nik,1,0,'');
			$pdf->Cell(80,6,$key->nama,1,0,'');
			$pdf->Cell(100,6,$key->alamat,1,0,'');
			$pdf->Cell(30,6,$key->telpon,1,1,'');
			$no++;
		}
		$pdf->Output();
	}
}
/* End of file Laporan.php */
/* Location: ./application/controllers/Laporan.php */