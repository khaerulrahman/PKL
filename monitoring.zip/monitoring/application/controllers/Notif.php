<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notif extends CI_Controller {

	public function index()
	{
		// Fiber Optic Cable
		$this->db->select('*, SUM(quantity) AS sum_quantity');
		$this->db->from('summary_stock_foc');
		$this->db->group_by('material');
		$query = $this->db->get();
		foreach ($query->result() as $key) {
			$material      = $key->material;
			$material_desc = $key->material_desc;
			$qty           = $key->sum_quantity;
			$this->db->where('material', $material);
			$this->db->where('jenis', 'foc');
			$query2 = $this->db->get('minimum_stock');
			if ($query2->num_rows() > 0) {
				foreach ($query2->result() as $key) {
					$safety_stock = $key->safety_stock;
				}
				if ($qty <= $safety_stock) {
				// Config Email
					$from_email = "disongoat@gmail.com";
					$config['protocol']  = 'smtp';
					$config['smtp_host'] = 'ssl://smtp.googlemail.com';
					$config['smtp_user'] = $from_email;
					$config['smtp_pass'] = 'akugatau';
					$config['smtp_port'] = 465;
					$config['mailtype']  = 'html';
					$config['charset']   = 'iso-8859-1';
					$config['wordwrap']  = TRUE;
					$this->load->library('email', $config);
					$this->email->set_newline("\r\n");
					$this->email->from($from_email, 'Admin');
					$to_email = 'adderson.hutagalung@iconpln.co.id';	
					$this->email->to($to_email);
					$this->email->subject('(FOC) Quantity Kurang Dari / Sama Dengan Safety Stock');
					$this->email->message('Material = '.$material.' | Material Description = '.$material_desc.' | Quantity = '.$qty.' | Safety Stock = '.$safety_stock);
					$this->email->send();
				}
			}
		}

		// Fiber Optic Terminal
		$this->db->select('*, SUM(quantity) AS sum_quantity');
		$this->db->from('summary_stock_fot');
		$this->db->group_by('material');
		$query = $this->db->get();
		foreach ($query->result() as $key) {
			$material      = $key->material;
			$material_desc = $key->material_desc;
			$qty           = $key->sum_quantity;
			$this->db->where('material', $material);
			$this->db->where('jenis', 'fot');
			$query2 = $this->db->get('minimum_stock');
			if ($query2->num_rows() > 0) {
				foreach ($query2->result() as $key) {
					$safety_stock = $key->safety_stock;
				}
				if ($qty <= $safety_stock) {
				// Config Email
					$from_email = "disongoat@gmail.com";
					$config['protocol']  = 'smtp';
					$config['smtp_host'] = 'ssl://smtp.googlemail.com';
					$config['smtp_user'] = $from_email;
					$config['smtp_pass'] = 'akugatau';
					$config['smtp_port'] = 465;
					$config['mailtype']  = 'html';
					$config['charset']   = 'iso-8859-1';
					$config['wordwrap']  = TRUE;
					$this->load->library('email', $config);
					$this->email->set_newline("\r\n");
					$this->email->from($from_email, 'Admin');
					$to_email = 'adderson.hutagalung@iconpln.co.id';	
					$this->email->to($to_email);
					$this->email->subject('(FOT) Quantity Kurang Dari / Sama Dengan Safety Stock');
					$this->email->message('Material = '.$material.' | Material Description = '.$material_desc.' | Quantity = '.$qty.' | Safety Stock = '.$safety_stock);
					$this->email->send();
				}
			}
		}
	}

	public function tes()
	{
		$from_email = "disongoat@gmail.com";
		$config['protocol']  = 'smtp';
		$config['smtp_host'] = 'ssl://smtp.googlemail.com';
		$config['smtp_user'] = $from_email;
		$config['smtp_pass'] = 'akugatau';
		$config['smtp_port'] = 465;
		$config['mailtype']  = 'html';
		$config['charset']   = 'iso-8859-1';
		$config['wordwrap']  = TRUE;
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->from($from_email, 'Admin');
		$to_email = 'fendy.anjapu@gmail.com';	
		$this->email->to($to_email);
		$this->email->subject('Berhasil');
		$this->email->message('Cron Job Success');
		$this->email->send();
	}

}

/* End of file Notif.php */
/* Location: ./application/controllers/Notif.php */