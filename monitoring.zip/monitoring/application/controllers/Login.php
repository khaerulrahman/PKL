<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->view('login');
	}

	public function signin()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$where = array(
			'username' => $username,
			'password' => sha1($password)
		);
		$cek = $this->db->get_where("login",$where)->num_rows();
		if($cek > 0) {
			$data_session = array(
				'user'   => $username,
			);
			$this->session->set_userdata($data_session);
			redirect(base_url('main'));
		} else {
			echo "<script>
			alert('Username atau Passsword Salah!');
			self.history.back();
			</script>";
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url());
	}

}

/* End of file Login.php */
/* Location: ./application/controllers/Login.php */