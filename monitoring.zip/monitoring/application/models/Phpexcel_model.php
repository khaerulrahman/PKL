<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Phpexcel_model extends CI_Model {

	public function upload_data_fot($filename){
		ini_set('memory_limit', '-1');
		$inputFileName = './upload/'.$filename;
		try {
			$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
		} catch(Exception $e) {
			die('Error loading file :' . $e->getMessage());
		}

		$worksheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
		$numRows = count($worksheet);

		for ($i=2; $i < ($numRows+1); $i++) { 
			$material      = $worksheet[$i]["A"];
			$material_desc = $worksheet[$i]["B"];
			$quantity      = $worksheet[$i]["H"];
			$posting_date  = $worksheet[$i]["I"];
			$posting_date  = date_format(date_create($posting_date),'m/d/Y');
			$posting_date  = date_format(date_create($posting_date),'Y-m-d');
			$ins           = array(
				"material"      => $material,
				"material_desc" => $material_desc,
				"val_type"      => $worksheet[$i]["C"],
				"movement"      => $worksheet[$i]["D"],
				"orderr"        => $worksheet[$i]["E"],
				"mvt"           => $worksheet[$i]["F"],
				"text"          => $worksheet[$i]["G"],
				"quantity"      => $quantity,
				"posting_date"  => $posting_date,
			);
			if ($material!=null) {
				$this->db->insert('penyerapan_fot', $ins);
			}
		}
	}

	public function upload_data_foc($filename){
		ini_set('memory_limit', '-1');
		$inputFileName = './upload/'.$filename;
		try {
			$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
		} catch(Exception $e) {
			die('Error loading file :' . $e->getMessage());
		}

		$worksheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
		$numRows = count($worksheet);

		for ($i=2; $i < ($numRows+1); $i++) {
			$material     = $worksheet[$i]["A"];
			$posting_date = $worksheet[$i]["J"];
			$posting_date = date_format(date_create($posting_date),'m/d/Y');
			$posting_date = date_format(date_create($posting_date),'Y-m-d');			
			$ins          = array(
				"material"      => $material,
				"material_desc" => $worksheet[$i]["B"],
				"val_type"      => $worksheet[$i]["C"],
				"movement"      => $worksheet[$i]["D"],
				"batch"         => $worksheet[$i]["E"],
				"orderr"        => $worksheet[$i]["F"],
				"mvt"           => $worksheet[$i]["G"],
				"text"          => $worksheet[$i]["H"],
				"quantity"      => $worksheet[$i]["I"],
				"posting_date"  => $posting_date,
			);
			if ($material!=null) {
				$this->db->insert('penyerapan_foc', $ins);
			}			
		}
	}

	public function upload_stock_fot($filename){
		ini_set('memory_limit', '-1');
		$inputFileName = './upload/'.$filename;
		try {
			$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
		} catch(Exception $e) {
			die('Error loading file :' . $e->getMessage());
		}

		$worksheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
		$numRows = count($worksheet);

		for ($i=2; $i < ($numRows+1); $i++) { 
			$material = $worksheet[$i]["A"];
			$ins = array(
				"material"      => $material,
				"material_desc" => $worksheet[$i]["B"],
				"batch"         => $worksheet[$i]["C"],
				"stock"         => $worksheet[$i]["D"],
				"satuan"        => $worksheet[$i]["E"],
			);
			if ($material!=null) {
				$this->db->insert('summary_stock_fot', $ins);
			}
		}
		$this->notif_send('summary_stock_fot','fot');
	}

	public function upload_stock_foc($filename){
		ini_set('memory_limit', '-1');
		$inputFileName = './upload/'.$filename;
		try {
			$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
		} catch(Exception $e) {
			die('Error loading file :' . $e->getMessage());
		}

		$worksheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
		$numRows = count($worksheet);

		for ($i=2; $i < ($numRows+1); $i++) { 
			$material = $worksheet[$i]["A"];
			$satuan = str_replace(',', '', $worksheet[$i]["D"]);
			$ins = array(
				"material"      => $material,
				"material_desc" => $worksheet[$i]["B"],
				"batch"         => $worksheet[$i]["C"],
				"stock"         => $satuan,
				"satuan"        => $worksheet[$i]["E"],
			);
			if ($material!=null) {
				$this->db->insert('summary_stock_foc', $ins);
			}
		}
		$this->notif_send('summary_stock_foc','foc');
	}

	public function notif_send($tabel='',$jenis='')
	{
		$query = $this->db->get($tabel);
		foreach ($query->result() as $key) {
			$material      = $key->material;
			$material_desc = $key->material_desc;
			$stock         = $key->stock;
			$this->db->where('material', $material);
			$this->db->where('jenis', $jenis);
			$query2 = $this->db->get('minimum_stock');
			if ($query2->num_rows() > 0) {
				foreach ($query2->result() as $key) {
					$minimum_stock = $key->minimum_stock;
				}
				if ($stock <= $minimum_stock) {
				// Config Email
					$from_email = "near.nedraver@gmail.com";
					$config['protocol']  = 'smtp';
					$config['smtp_host'] = 'ssl://smtp.googlemail.com';
					$config['smtp_user'] = $from_email;
					$config['smtp_pass'] = 'y0b4ng3r';
					$config['smtp_port'] = 465;
					$config['mailtype']  = 'html';
					$config['charset']   = 'iso-8859-1';
					$config['wordwrap']  = TRUE;
					$this->load->library('email', $config);
					
					$this->email->set_newline("\r\n");
					$this->email->from($from_email, 'Admin');
					$to_email = 'nurbaeti@iconpln.co.id';
					$this->email->to($to_email);
					$this->email->subject('Quantity Kurang Dari / Sama Dengan Safety Stock');
					$this->email->message('Material = '.$material.' | Material Description = '.$material_desc.' | Stock = '.$stock.' | Minimum Stock = '.$minimum_stock);
					$this->email->send();

					$this->email->set_newline("\r\n");
					$this->email->from($from_email, 'Admin');
					$to_email = 'adderson.hutagalung@iconpln.co.id';
					$this->email->to($to_email);
					$this->email->subject('Quantity Kurang Dari / Sama Dengan Safety Stock');
					$this->email->message('Material = '.$material.' | Material Description = '.$material_desc.' | Stock = '.$stock.' | Minimum Stock = '.$minimum_stock);
					$this->email->send();
				}
			}
		}
	}

}

/* End of file Phpexcel_model.php */
/* Location: ./application/models/Phpexcel_model.php */